﻿using APIalmoxarifado.Infraestrutura;
using APIalmoxarifado.Models;
using Microsoft.EntityFrameworkCore;

namespace APIalmoxarifado.Repository
{
    public class MotivoSaidaRepository : IMotivoSaidaRepository
    {
        ConexaoSQL bdConexao = new ConexaoSQL();

        public void Add(MotivoSaida motivoSaida)
        {
            bdConexao.Add(motivoSaida);
            bdConexao.SaveChanges();
        }
        public List<MotivoSaida> GetAll()
        {
            return bdConexao.MotivoSaida.ToList();
        }

      

     
    }
}

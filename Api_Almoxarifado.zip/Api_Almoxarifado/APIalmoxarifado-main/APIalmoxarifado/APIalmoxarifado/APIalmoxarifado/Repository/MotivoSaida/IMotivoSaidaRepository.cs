﻿using APIalmoxarifado.Infraestrutura;
using APIalmoxarifado.Models;
using Microsoft.EntityFrameworkCore;

namespace APIalmoxarifado.Repository
{
    public interface IMotivoSaidaRepository
    {
        List<MotivoSaida> GetAll();

        void Add(MotivoSaida motivoSaida);

        

    }
}
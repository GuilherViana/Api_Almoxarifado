﻿namespace APIalmoxarifado.Repository
{
    public class CategoriaMotivo
    {
    }
}

﻿namespace APIalmoxarifado.Repository
{
    public interface ICategoriaMotivoRepository
    {
        object? GetAll();
    }
}

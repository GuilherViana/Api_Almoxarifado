﻿namespace APIalmoxarifado.ViewModel
{
    public class ProdutoViewModelSemFoto
    {

        public string nome { get; set; }
        public int estoque { get; set; } = 0;
        public string? photourl { get; set; }
    }
}

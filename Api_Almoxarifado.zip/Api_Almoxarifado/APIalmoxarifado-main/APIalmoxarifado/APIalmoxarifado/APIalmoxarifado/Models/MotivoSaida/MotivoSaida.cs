﻿namespace APIalmoxarifado.Models
{
    public class MotivoSaida
    {
        public int MotId { get; set; }
        public string descricao { get; set; }

        public int CatId { get; set; }
    }
}

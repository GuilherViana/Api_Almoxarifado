﻿namespace APIalmoxarifado.Models
{
    public class Departamento
    {
        public int id { get; set; }
        public string descricao { get; set; }

        public bool ativado { get; set; }
    }
}

﻿namespace APIalmoxarifado.Models
{
    public class CategoriaMotivo
    {
        public int CatId { get; set; }
        public string descricao { get; set; }
    }
}

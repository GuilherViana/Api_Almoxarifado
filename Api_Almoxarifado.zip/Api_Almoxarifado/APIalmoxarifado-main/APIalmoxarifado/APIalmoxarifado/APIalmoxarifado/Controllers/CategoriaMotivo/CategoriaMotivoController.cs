﻿using APIalmoxarifado.Models;
using APIalmoxarifado.Repository;
using Microsoft.AspNetCore.Mvc;

namespace APIalmoxarifado.Controllers
{
    [ApiController]
    [Route("api/v1/categoriamotivo")]
    public class CategoriaMotivoController : Controller
    {
        private readonly ICategoriaMotivoRepository _categoriamotivoRepository;

        public CategoriaMotivoController(ICategoriaMotivoRepository repositorio)
        {
            _categoriamotivoRepository = repositorio;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_categoriamotivoRepository.GetAll());
        }
    }
}

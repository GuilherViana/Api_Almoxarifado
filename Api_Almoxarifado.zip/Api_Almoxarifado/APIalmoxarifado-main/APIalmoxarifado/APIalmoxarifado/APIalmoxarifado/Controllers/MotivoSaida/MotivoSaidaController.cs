﻿using APIalmoxarifado.Models;
using APIalmoxarifado.Repository;
using Microsoft.AspNetCore.Mvc;

namespace APIalmoxarifado.Controllers
{
    [ApiController]
    [Route("api/v1/motivosaida")]
    public class MotivoSaidaController : Controller
    {
        private readonly IMotivoSaidaRepository _motivoSaidaRepository;

        public MotivoSaidaController(IMotivoSaidaRepository repositorio)
        {
            _motivoSaidaRepository = repositorio;
        }

        [HttpGet]
        [Route("GetAll")]

        public IActionResult GetAll()
        {
            return Ok(_motivoSaidaRepository.GetAll());
        }

        


    }
}